import pymysql

def mysql_connect():
    connect = pymysql.connect(
        host='localhost',
        port=3306,
        user='root',
        passwd='123',
        db='myDB',
        charset='utf8'
    )
    if(connect!=None):
        print("connect mysql success!")
        return connect.cursor()
    
    
def mysql_find(cursor,sql):
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        for row in results:
            name = row[1]
            age = row[2]
            sex =row[3]
            iden = row[4]
            nation = row[5]
            print ("name=%s,age=%s,sex=%s,iden=%s,nation=%s" % \
                   (name, str(age), sex, iden, nation ))
            return results
    except:
        print ("Error: unable to fecth data")
