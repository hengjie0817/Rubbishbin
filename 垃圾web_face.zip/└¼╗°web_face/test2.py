#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import face_recognition
import cv2
import numpy as np
import mysql
import os

video_capture = cv2.VideoCapture(0)

# 保存的图片目录名(绝对路径)
file_dir = r'/home/pi/last/images/'
rectangular_dir = r'/home/pi/last/rec.jpg'


# 保存的图片文件名
image_name_list = []


# 得到文件名
def file_name(image_name_list):   
    # root是指当前目录路径(文件夹的绝对路径)
    # dirs是指路径下所有的子目录(文件夹里的文件夹)
    # files是指路径下所有的文件(文件夹里所有的文件)
    for root,dirs,files in os.walk(file_dir):
        for file in files:
            # if os.path.splitext(file)[1] == '.jpg':
                image_name_list.append(os.path.join(file))
                print(image_name_list)
                            
file_name(image_name_list)


# 创建已知面孔及其名称数组
known_face_encodings = []
known_face_names = []


# 加载图片并学习如何识别它
def konwn_face(known_face_encodings,known_face_names):
    for image_name in image_name_list :
        character_image = face_recognition.load_image_file(file_dir+image_name)
        character_face_encoding = face_recognition.face_encodings(character_image)[0]
        known_face_encodings.append(character_face_encoding)

    for root,dirs,files in os.walk(file_dir):
        for file in files:
                known_face_names.append(os.path.splitext(file)[0])
                                
konwn_face(known_face_encodings,known_face_names)


# In[ ]:


# 初始化一些变量
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True
cursor=mysql.mysql_connect();

while True:
    # 抓取一帧视频
    ret, frame = video_capture.read()
    
    #text
    rectangular_image = cv2.imread(rectangular_dir)
    font = cv2.FONT_HERSHEY_DUPLEX
    cv2.putText(rectangular_image, "FACE PLEA!", (0 + 150, 0 + 330), font, 4, (255, 255, 255), 2)
    #cv2.rectangle(frame, (0, frame.shape[1]-200), (frame.shape[0], frame.shape[1]), (255, 255, 255), cv2.FILLED)
    
    # 调整视频帧到1/4大小，以更快的人脸识别处理
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # 将图像从BGR颜色(OpenCV使用)转换为RGB颜色(face_recognition使用)
    rgb_small_frame = small_frame[:, :, ::-1]

    # 只处理其他帧的视频以节省时间
    if process_this_frame:
        # 找到当前视频帧中所有的面和面编码
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
        
        face_names = []
        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            # 查看该面孔是否与已知面孔匹配
            #阈值太低容易造成无法成功识别人脸，太高容易造成人脸识别混淆 默认阈值tolerance为0.6（亚洲人一般要用低点，不然你就是周杰伦了）
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding,tolerance=0.5)
            
            # 默认为unknown
            name = "Unknown"

            # 使用与新面孔距离最小的已知面孔，即看测试图像与已知面孔之间有多远
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            
            #best_match_index为face_distances中最小值的下标
            best_match_index = np.argmin(face_distances)
            
            #如果face_distances[best_match_index]小于0.5（截止值，原本想加上的，但仔细一想又好像不对），matches[best_match_index]比较结果为真
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            face_names.append(name)

    process_this_frame = not process_this_frame


    # 关于显示效果不要刷新太快的问题
    #（刷新问题再怎么改，只要没有识别到就会变化，毕竟无法预测接下来的情况而做出调整，而且人眼能够识别的帧数还挺高的）
    # 换个角度思考就是识别度有点低
    #（有可能是摄像头的问题，摄像头不好或者摄像头离得太远导致无法识别）
    # (还有可能是因为small_frame缩放的问题，人脸被缩放了，因此辨别难度也增加了)
    # (所以 识别精度 和 识别速度 之间的平衡考虑一下呗)
    
    
        # Display the results
        # 显示结果
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # 因为我们检测到的帧被缩放到1/4大小，所以缩放后的面位置
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # 在脸周围画一个方框
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        #mysql
        rectangular_image = cv2.imread(rectangular_dir)
        id=name
        sql = "SELECT * FROM User                    WHERE id = %s" % (id)
        results=mysql.mysql_find(cursor,sql)
        if(results!=None):
            for row in results:
                lname = row[1]
                age = row[2]
                sex =row[3]
                iden = row[4]
                nation = row[5]

            # 画一个有名字的标签
            #cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(rectangular_image, "NAME: "+lname, (0 + 50, 0 + 100), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "AGE: "+str(age), (0 + 50, 0 + 200), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "SEX: "+sex, (0 + 50, 0 + 300), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "IDENTITY: "+iden, (0 + 50, 0 + 400), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "NATION: "+nation, (0 + 50, 0 + 500), font, 2.0, (255, 255, 255), 2)
    
    
    # 边框图片地址
    border_dir = r'/home/pi/last/bor.png'
    
    # 边框图片
    bor_image = cv2.imread(border_dir)
    
    # 变更为画布的大小
    bor_image = cv2.resize(bor_image, (frame.shape[1], frame.shape[0]) )
    
    #roi
    rows,cols,channels = bor_image.shape
    roi = frame[0:rows, 0:cols ]
    
    # 利用mask合成
    # 将图片灰度化（灰度0-255  白255  黑0）
    bor_image_gray = cv2.cvtColor(bor_image,cv2.COLOR_BGR2GRAY)
    
    # 灰度图 把 大于175（即不感兴趣）的值改为 255 ，也就是变为白色   
    # 现在是mask中 兴趣区域-->黑色   无兴趣区域-->白色
    ret, mask = cv2.threshold(bor_image_gray, 180, 255, cv2.THRESH_BINARY)
    
    # 把mask取反，现在是mask_not中 兴趣区域-->白色   无兴趣区域-->黑色
    mask_not = cv2.bitwise_not(mask)
    
    # 对图片和mask进行取与操作，作用相当于把mask中为黑色（）的部分，
    # 在图片中也附黑，白色部分不变。
    img1_bg = cv2.bitwise_and(roi,roi,mask = mask)
    
    # 对边框图片和mask_not进行取与操作，作用相当于把mask中为黑色的部分，
    # 在边框图片中也附黑，白色部分不变。
    img2_bg = cv2.bitwise_and(bor_image,bor_image,mask = mask_not)
    
    # 进行图片的加和
    dst = cv2.add(img1_bg,img2_bg)
    frame[0:rows, 0:cols ] = dst
    
    
     #add the rectangular
    rectangular_image = cv2.resize(rectangular_image, (frame.shape[1], frame.shape[0]), )
    vtich = np.vstack((frame, rectangular_image))
    
    
    # 显示结果图像
    cv2.namedWindow("Video", 0)
    cv2.resizeWindow("Video", 400, 600)
    frame=cv2.resize(frame, (0, 0), fx=1, fy=1)
    cv2.imshow('Video', vtich)
    
    # Hit 'q' on the keyboard to quit!
    # 按键盘上的“q”键退出!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
        
# 释放摄像头的句柄
video_capture.release()
cv2.destroyAllWindows()


# In[ ]:




