#!/usr/bin/env python
# coding: utf-8

# In[1]:


import face_recognition
import cv2
import numpy as np
import mysql
import os

video_capture = cv2.VideoCapture(0)

# In[ ]:


# 保存的图片目录名(绝对路径)
file_dir = r'/home/pi/last/images/'
rectangular_dir=r'/home/pi/last/rec.jpg'


# 保存的图片文件名
image_name_list = []

# 得到文件名
def file_name(image_name_list):   
    # root是指当前目录路径(文件夹的绝对路径)
    # dirs是指路径下所有的子目录(文件夹里的文件夹)
    # files是指路径下所有的文件(文件夹里所有的文件)
    for root,dirs,files in os.walk(file_dir):
        for file in files:
            # if os.path.splitext(file)[1] == '.jpg':
                image_name_list.append(os.path.join(file))
                print(image_name_list)
                            
file_name(image_name_list)


# In[ ]:


# 创建已知面孔及其名称数组
known_face_encodings = []
known_face_names = []

# 加载图片并学习如何识别它
def konwn_face(known_face_encodings,known_face_names):
    for image_name in image_name_list :
        character_image = face_recognition.load_image_file(file_dir+image_name)
        character_face_encoding = face_recognition.face_encodings(character_image)[0]
        known_face_encodings.append(character_face_encoding)

    for root,dirs,files in os.walk(file_dir):
        for file in files:
                known_face_names.append(os.path.splitext(file)[0])
                
                
konwn_face(known_face_encodings,known_face_names)


# In[ ]:


# 初始化一些变量
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True
cursor=mysql.mysql_connect();

while True:
    # 抓取一帧视频
    ret, frame = video_capture.read()
    #text
    rectangular_image = cv2.imread(rectangular_dir)
    font = cv2.FONT_HERSHEY_DUPLEX
    cv2.putText(rectangular_image, "FACE PLEA!", (0 + 150, 0 + 330), font, 4, (255, 255, 255), 2)
    #cv2.rectangle(frame, (0, frame.shape[1]-200), (frame.shape[0], frame.shape[1]), (255, 255, 255), cv2.FILLED)
    # 调整视频帧到1/4大小，以更快的人脸识别处理
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # 将图像从BGR颜色(OpenCV使用)转换为RGB颜色(face_recognition使用)
    rgb_small_frame = small_frame[:, :, ::-1]

    # 只处理其他帧的视频以节省时间
    if process_this_frame:
        # 找到当前视频帧中所有的面和面编码
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        face_names = []
        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            # 查看该面孔是否与已知面孔匹配
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"

            # 使用与新面孔距离最小的已知面孔
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            face_names.append(name)

    process_this_frame = not process_this_frame


    # Display the results
    # 显示结果
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up face locations since the frame we detected in was scaled to 1/4 size
        # 因为我们检测到的帧被缩放到1/4大小，所以缩放后的面位置
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # Draw a box around the face
        # 在脸周围画一个方框
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
        
        #mysql
        rectangular_image = cv2.imread(rectangular_dir)
        id=name
        sql = "SELECT * FROM User \
               WHERE id = %s" % (id)
        results=mysql.mysql_find(cursor,sql)
        if(results!=None):
            for row in results:
                lname = row[1]
                age = row[2]
                sex =row[3]
                iden = row[4]
                nation = row[5]
                
            # Draw a label with a name below the face
            # 画一个有名字的标签
            #cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(rectangular_image, "NAME: "+lname, (0 + 50, 0 + 100), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "AGE: "+str(age), (0 + 50, 0 + 200), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "SEX: "+sex, (0 + 50, 0 + 300), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "IDENTITY: "+iden, (0 + 50, 0 + 400), font, 2.0, (255, 255, 255), 2)
            cv2.putText(rectangular_image, "NATION: "+nation, (0 + 50, 0 + 500), font, 2.0, (255, 255, 255), 2)
    # Display the resulting image
    # 显示结果图像
    cv2.namedWindow("Video", 0)
    cv2.resizeWindow("Video", 400, 600)
    frame=cv2.resize(frame, (0, 0), fx=1, fy=1)
    
    #add the rectangular
    rectangular_image = cv2.resize(rectangular_image, (frame.shape[1], frame.shape[0]), )
    vtich = np.vstack((frame, rectangular_image)) 
    cv2.imshow('Video', vtich)
    
    # Hit 'q' on the keyboard to quit!
    # 按键盘上的“q”键退出!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release handle to the webcam
# 释放摄像头的句柄
video_capture.release()
cv2.destroyAllWindows()

