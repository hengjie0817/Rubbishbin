<?php
$servername="lnmp_mysql-container";
$username="root";
$password="123";
$dbname="myDB";
header('Content-type: application/json');
$type=$_POST['Type'];
$id=$_POST['Id'];
$name=$_POST['Name'];
$age=$_POST['Age'];
$sex=$_POST['Sex'];
$nation=$_POST['Nation'];
$identity=$_POST['Identity'];
if($type=="abc")
{
	try{
		$pdo = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		$sql="INSERT INTO User(id,name,age,sex,identity,nation)
		VALUES ($id,'$name',$age,'$sex','$identity','$nation')";
		$pdo->exec($sql);
    		echo "新记录插入成功";
		
	}catch(PDOException $e)
	{
		echo $e->getMessage();
	}
}
else
{
	try{
		$pdo = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		$sql="select * from User";
		$res=$pdo->query($sql);
		$row = json_encode($res->fetchAll(PDO::FETCH_ASSOC),JSON_UNESCAPED_UNICODE);
		echo $row;
		
	}catch(PDOException $e)
	{
		echo $e->getMessage();
	}
}
?>