package fomula;
//在新建Multinomial类构造函数的参数里输入所需要的参数(int X,String 字符串)
//字符串依照“y=x^2+2x+1”的形式，指数带^，系数后不加*，并且系数可以是整数也可以是小数
//具体操作代码在multinomial类里面
public class work {
	public static void main(String[]args)
	{
		FomulaCreator m;
		m=new Multinomial(3,"y=x+3x^2+1");
		System.out.println(m.getvalue());
		m=new Differential(2,"y=x+3x^2+1");
		System.out.println(m.getvalue());
	}
}
