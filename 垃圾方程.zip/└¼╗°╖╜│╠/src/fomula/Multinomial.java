package fomula;
import java.util.Enumeration;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//***************抽象算数工厂**************//
interface FomulaCreator
{
	public double getvalue();
	
}
//*****************************************//


//***************简单多项式类**************//
class Multinomial implements FomulaCreator 
{
	protected int X;
	protected String Str;
	//多项式的X与Y属性值
	private Vector<Item> v1=new Vector<Item>();//多项式的变量X类的每个对象
	
	public Multinomial(int x,String s)	//构造函数确定多项式属性
	{
		X=x;
		String []arr=s.split("=");
		Str=arr[1];
		creatItems();//在构造函数里先提取各项
	}
	
	
	private  void creatItems()		//取出字符串中各项的属性
	{
		String [] group=new String[50];int i=0;int judge=1;
		while(judge==1)					//正则表达式逐一判断提取
		{	
			String f="^([+-]?[0-9]*\\.?[0-9]*x\\^[-]?[0-9]+)";
			String y="^([+-]?[0-9]*\\.?[0-9]*x?)";
			Pattern r=Pattern.compile(f);
			Matcher m=r.matcher(Str);
			if(m.find()) 
			{
				group[i]=m.group(0);
				i++;
				if(!(Str.equals(group[i-1])))
				{
					Str=Str.substring(group[i-1].length());
				}
				else judge=0;
			}
			else
			{
				r=Pattern.compile(y);
				m=r.matcher(Str);
				if(m.find()) 
				{ 
					
					group[i]=m.group(0);
					i++;
					if(!(Str.equals(group[i-1])))
					{
						Str=Str.substring(group[i-1].length());
					}
					else judge=0;
				}
				
			}
			
		}
			for(int j=0;j<i;j++)		//找指数系数然后存入VECTOR变量
			{
				int index;double coefficient;
				coefficient=getCoefficient(group[j]);//开始找系数
				index=getIndex(group[j]);//开始找次方
				Item xx=new Item(coefficient,index);
				v1.add(xx);
			}
		
	}
	private double getCoefficient(String s)	//找系数的函数
	{
		Pattern rr=Pattern.compile("^[+-]?[0-9]*\\.?[0-9]*\\.?[0-9]+");
		Matcher mm=rr.matcher(s);
		double coefficient;
		if(mm.find()) 
			coefficient=Double.parseDouble(mm.group(0));
		else if(s.equals("-")) 
			coefficient=-1;
		else
			coefficient=1;
		return coefficient; 
	}
	private int getIndex(String s)	//找指数的函数
	{
		int index;index=0;
		Pattern rr=Pattern.compile("x\\^[-]?[0-9]+$");
		Matcher mm=rr.matcher(s);
		if(mm.find())
		{
			mm=Pattern.compile("[-]?[0-9]+$").matcher(mm.group(0));
			if(mm.find()) index=Integer.parseInt(mm.group(0));
		}
		else if(Pattern.matches(".*x.*", s)) index=1;
		else index=0;
		return index;
	}
	public Vector<Item> getItemvector()
	{
		return v1;
	}
	public double getvalue() //计算多项式的值
	{
		double y=0;
        Enumeration<Item> elements = v1.elements();
        while (elements.hasMoreElements()) 
        {
            y=y+elements.nextElement().getvalue(X);
        }
        return y;
    }
}
//*****************************************//
	
//***************派生导数类**************//
class Differential extends Multinomial
{
	private Vector<DiffItem> v2=new Vector<DiffItem>();
	public Differential(int x, String s)
	{
		super(x, s);
		X=x;
		Str=s;
		creatDiffItems();
	}
	private void creatDiffItems()		//重构导数项
	{
		Multinomial m=new Multinomial(X,Str);
		Enumeration<Item> element=m.getItemvector().elements();
		while(element.hasMoreElements())
		{
			Item a=element.nextElement();
			DiffItem d=new DiffItem(a.getcoefficient(),a.getindex());
			v2.add(d);
		}
	}
	public double getvalue() //计算多项式的值
	{
		double y=0;
        Enumeration<DiffItem> elements = v2.elements();
        while (elements.hasMoreElements()) 
        {
            y=y+elements.nextElement().getvalue(X);
        }
        return y;
    }
	
}
//*****************************************//

//***************项（产品）**************//
interface IntemProduct
{
	public double getvalue();
	public int getindex();
	public double getcoefficient();
}
//*****************************************//

//***************多项式的项**************//
class Item						//多项市的项类
{
	protected int index;
	protected double coefficient;
	
	public Item(double co,int in)
	{
		index=in;
		coefficient=co;
	}
	
	public int getindex()
	{
		return index;
	}
	public double getcoefficient()
	{
		return coefficient;
	}
	public double getvalue(int x)
	{
		return coefficient*Math.pow(x, index);
	}
}
//*****************************************//

//***************派生倒数项**************//
class DiffItem extends Item
{
	public DiffItem(double co, int in)	//重构导数项的构造函数
	{
		super(co, in);
		if(in!=0) 
		{
			coefficient=co*in;
			index=in-1;
		}
		else 
		{
			coefficient=0;
			index=0;
		}
	}
}
//*****************************************//